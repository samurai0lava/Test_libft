/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstdelone.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: iouhssei <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/16 23:42:54 by iouhssei          #+#    #+#             */
/*   Updated: 2023/11/16 23:43:57 by iouhssei         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_lstdelone(t_list *lst, void (*del)(void*))
{
	if (lst && del)
	{
		del(lst->content);
		free(lst);
	}
}
/*
void	delete_content(void *content)
{
    free(content);
}

int main()
{
    int data1 = 45;
    int data2 = 56;

    t_list *node1 = is_new(&data1);
    t_list *node2 = is_new(&data2);

    printf("Nodes before the deletion:\n");
    printf("%d\n", *(int *)(node1->content));
    printf("%d\n", *(int *)(node2->content));

    ft_lstdelone(node1, delete_content);

    // Now, node1 is freed, and you should not access it or its content
    printf("Node after the deletion:\n");
    printf("%d\n", *(int *)(node2->content));

    // Make sure to free node2 as well
    ft_lstdelone(node2, delete_content);

    return 0;
}
*/
