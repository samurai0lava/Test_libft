/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memmove.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: iouhssei <iouhssei@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/03 21:48:53 by iouhssei          #+#    #+#             */
/*   Updated: 2023/11/16 23:45:14 by iouhssei         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memmove(void *dest, const void *src, size_t n)
{
	const char	*s;
	char		*d;

	if (dest == src)
		return (dest);
	s = (const char *)src;
	d = (char *)dest;
	while (n > 0)
	{
		n--;
		d[n] = s[n];
	}
	return (dest);
}
