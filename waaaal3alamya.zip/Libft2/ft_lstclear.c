/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstclear.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: iouhssei <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/11/17 13:42:02 by iouhssei          #+#    #+#             */
/*   Updated: 2023/11/17 13:57:57 by iouhssei         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"
#include <stdio.h>
#include <stdlib.h>

void ft_lstclear(t_list **lst, void (*del)(void*))
{
	if (lst == NULL || del == NULL)
		return;
	t_list *tmp = *lst;
    t_list *next;

	while(tmp)
	{
		next = tmp->next;
		del(tmp->content);
		tmp = next;
	}	
	*lst = NULL;
}
	
void	delete_content(void *content)
{
	free(content);
}
/*
int main() {
    // Create a linked list with some sample data
    t_list *node1 = malloc(sizeof(t_list));
    node1->content = ft_strdup("Node 1");
    node1->next = NULL;

    t_list *node2 = malloc(sizeof(t_list));
    node2->content = ft_strdup("Node 2");
    node2->next = NULL;

    t_list *node3 = malloc(sizeof(t_list));
    node3->content = ft_strdup("Node 3");
    node3->next = NULL;

    // Link the nodes
    node1->next = node2;
    node2->next = node3;

    // Print the original list
    t_list *current = node1;
    while (current != NULL) {
        printf("%s\n", (char *)current->content);
        current = current->next;
    }

    // Clear the list using ft_lstclear
    ft_lstclear(&node1, delete_content);

    // Print the cleared list (should be empty)
    current = node1;
    while (current != NULL) {
        printf("%s\n", (char *)current->content);
        current = current->next;
    }

    return 0;
}
*/